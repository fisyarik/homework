﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Math;

namespace Formule
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void tbx_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(tbx.Text);
            int z = Convert.ToInt32(tbz.Text);
            int y = Convert.ToInt32(tby.Text);
            double F = 5 * Atan(x) - 0.25 * Acos(x) * ((x + z * Abs(x - y) + x * x) / (Abs(x - y) * z + x * x));
            label5.Text = F.ToString();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
